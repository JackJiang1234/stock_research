#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
弄懂公司一页纸 V1.1.0 — 估值计算脚本（同一输入同一输出，防 LLM 计算幻觉）
用法: python calc_valuation.py <估值数据.json>
覆盖: PE/PB 递推计算 / 历史分位(排除异常值) / CAGR / 估值方法提示

输入 JSON 结构：
  company 公司名 | market_cap 总市值 | net_profit 归母净利(TTM或年化) | net_assets 归母净资产 |
  pe/pb 已知倍数(缺失时脚本递推) | pe_series/pb_series 历史序列数组(≥30个交易日,分位计算用) |
  revenue_start/revenue_end/years CAGR 三件套 | dps 每股股息 | price 现价
  单位统一（亿元或亿美元，全文一致）；缺数据字段省略禁填 0"""
import json, argparse

def r2(x): return round(x, 2) if isinstance(x, (int, float)) else None
def sd(a, b):
    if a is None or b is None or b == 0: return None
    return a / b

def percentile(series, value):
    """分位计算：先排除异常值（非正数与极端值），再算当前值百分位"""
    if not series or value is None: return None
    valid = sorted(v for v in series if v is not None and v > 0)
    if len(valid) < 30:
        return {"percentile": None, "sample_days": len(valid),
                "warning": "样本不足30个交易日，分位参考性弱"}
    lo, hi = valid[0], valid[-1]
    trimmed = [v for v in valid if v <= hi - (hi - lo) * 0.02] or valid  # 剔头2%极端值
    below = sum(1 for v in trimmed if v <= value)
    return {"percentile": r2(below / len(trimmed) * 100), "sample_days": len(trimmed)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input"); ap.add_argument("--out", default=None)
    args = ap.parse_args()
    d = json.load(open(args.input, encoding="utf-8"))
    out = {"skill": "company-one-pager", "version": "1.1.0", "company": d.get("company"),
           "calculation_guarantee": "同一输入同一输出；缺数据标【无数据】禁 0 填充", "data_gaps": []}

    mcap, np_, na = d.get("market_cap"), d.get("net_profit"), d.get("net_assets")
    if d.get("pe") is None and mcap and np_:
        out["pe_derived"] = r2(sd(mcap, np_)); out["pe_source"] = "递推(市值÷归母净利)"
    else:
        out["pe"] = d.get("pe")
    if d.get("pb") is None and mcap and na:
        out["pb_derived"] = r2(sd(mcap, na)); out["pb_source"] = "递推(市值÷归母净资产)"
    else:
        out["pb"] = d.get("pb")

    for name, key in (("PE", "pe_series"), ("PB", "pb_series")):
        v = out.get(f"{name.lower()}_derived") or d.get(name.lower())
        p = percentile(d.get(key, []), v)
        if p: out[f"{name}_percentile"] = p

    # CAGR（rev0→revN, N 年）
    r0, rN, yrs = d.get("revenue_start"), d.get("revenue_end"), d.get("years")
    if all(x is not None for x in (r0, rN, yrs)) and r0 > 0 and yrs > 0:
        out["revenue_cagr"] = f"{((rN/r0)**(1/yrs)-1)*100:.2f}%"
    out["dividend_yield"] = f"{sd(d.get('dps'), d.get('price'))*100:.2f}%" if d.get("dps") and d.get("price") else None

    s = json.dumps(out, ensure_ascii=False, indent=2)
    if args.out: open(args.out, "w", encoding="utf-8").write(s); print(f"written: {args.out}")
    else: print(s)

if __name__ == "__main__":
    main()
